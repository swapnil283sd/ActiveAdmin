# Bootstrap-Repository
This repository is ready to code structure for implementing Bootstrap code. You can just download it and start coding. It will help you minimize time required for initial setup of setting up local CDN paths of not only bootstrap but also font awesome CSS.
